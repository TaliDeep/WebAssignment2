export class Exercise {
    exercise: string;
    workoutID: string;
    description: string;
    sets: string;
    repetitions: string;
}
