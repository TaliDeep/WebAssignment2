export class Workout {
    workout: string;
}
